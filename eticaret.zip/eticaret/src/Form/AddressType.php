<?php

namespace App\Form;

use App\Entity\Address;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CountryType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TelType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class AddressType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('name', TextType::class, [
                'label' => 'Adres Adı',
                'attr' => [
                    'placeholder' => 'ex: Ev'
                ]
            ])
            ->add('firstname', TextType::class, [
                'label' => 'Ad'
            ])
            ->add('lastname', TextType::class, [
                'label' =>'Soyad'
            ])
            ->add('company', TextType::class, [
                'label' => 'Şirket(İsteğe Bağlı)',
                'required' => false,
            ])
            ->add('address', TextType::class, [
                'label' => 'Adres',
                'attr' => [
                    'placeholder' => 'ex:12.cadde Çankaya'
                ]
            ])
            ->add('postal', TextType::class, [
                'label' => 'Posta Kodu'
            ])
            ->add('city', TextType::class, [
                'label' => 'Şehir'
            ])
            ->add('country', CountryType::class, [
                'label' => 'Ülke'
            ])
            ->add('phone', TelType::class, [
                'label' => 'Telefon'
            ])
            ->add('submit', SubmitType::class, [
                'label' => 'Adresi Kaydet', 
                'attr' => [
                    'class' => 'btn btn-info btn-block mt-2'
                ]
                
            ])
        ;
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => Address::class,
        ]);
    }
}
