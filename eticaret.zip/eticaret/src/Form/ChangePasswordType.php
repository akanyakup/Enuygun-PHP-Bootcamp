<?php

namespace App\Form;

use App\Entity\User;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\RepeatedType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\Length;
use Symfony\Component\Validator\Constraints\NotBlank;

class ChangePasswordType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('email', EmailType::class, [
                'disabled' => true,
                'label' => 'eposta Adresi'
            ])
            ->add('firstname', TextType::class, [
                'disabled' => true,
                'label' => 'Ad'
            ])
            ->add('lastname', TextType::class, [
                'disabled' => true,
                'label' => 'Soyad'
            ])
            ->add('old_password', PasswordType::class, [
                'label' => 'Mevcut Şifre',
                'mapped' => false,
                'attr' => [
                    'placeholder' => 'Lütfen mevcut şifrenizi giriniz'
                ]
            ])
            ->add('new_password', RepeatedType::class, [
                'type' => PasswordType::class,
                'invalid_message' => 'Les mots de passe doivent être identiques',
                'options' => ['attr' => ['class' => 'password-field']],
                'required' => true,
                'first_options'  => [
                    'label' => 'Yeni Şifre',
                    'attr' => ['placeholder' => 'Yeni şifreyi giriniz']
                ],
                'second_options' => [
                    'label' => 'Şifreyi Tekrar Girin',
                    'attr' => ['placeholder' => 'Şifreyi Onayla ']
                ],
                'mapped' => false,
                'attr' => [
                    'autocomplete' => 'new-password'
                ],
                'constraints' => [
                    new NotBlank([
                        'message' => 'lütfen bir şifre girin',
                    ]),
                    new Length([
                        'min' => 4,
                        'minMessage' => 'Şifreniz en az 8 karakter içermelidir',
                        'max' => 4096,
                    ]),
                ],
            ])
            ->add('submit', SubmitType::class, [
                'label' => 'Değişiklikleri Kaydet',
                'attr' => [
                    'class' => 'btn btn-outline-success'
                ]
            ])
        ;
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => User::class,
        ]);
    }
}
