<?php

namespace App\Controller;

use App\Model\Cart;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class CartController extends AbstractController
{
    /**
     * Ürünler nesneleri ile miktar ve fiyat toplamlarını içeren ayrıntılı bir alışveriş sepeti  
     * 
     * @param Cart $cart
     * @return Response
     */
    #[Route('/sepetim', name: 'cart')]
    public function index(Cart $cart): Response
    {
        $cartProducts = $cart->getDetails();

        return $this->render('cart/index.html.twig', [
            'cart' => $cartProducts['products'],
            'totalQuantity' => $cartProducts['totals']['quantity'],
            'totalPrice' =>$cartProducts['totals']['price']
        ]);
    }

    /**
     * Sepete ürün ekleme ve miktarını artırma
     * @param Cart $cart
     * @param int $id
     * @return Repsonse
     */
    #[Route('/sepet/ekle/{id}', name: 'add_to_cart')]
    public function add(Cart $cart, int $id): Response
    {
        $cart->add($id);
        return $this->redirectToRoute('cart');
    }

    /**
     * Sepetteki bir ürün için miktarı 1 azaltır
     * @param Cart $cart
     * @param int $id
     * @return Repsonse
     */
    #[Route('/sepet/azalt/{id}', name: 'decrease_item')]
    public function decrease(Cart $cart, int $id): Response
    {
        $cart->decreaseItem($id);
        return $this->redirectToRoute('cart');
    }
    
    /**
     * Alışveriş sepetinden bir ürünü siler
     *
     * @param Cart $cart
     * @return Response
     */
    #[Route('/sepet/sil/{id}', name: 'remove_cart_item')]
    public function removeItem(Cart $cart, int $id): Response
    {
        $cart->removeItem($id);
        return $this->redirectToRoute('cart');
    }

    /**
     * Sepeti tamamen boşaltır
     *
     * @param Cart $cart
     * @return Response
     */
    #[Route('/sepet/sil/', name: 'remove_cart')]
    public function remove(Cart $cart): Response
    {
        $cart->remove();
        return $this->redirectToRoute('product');
    }
}
